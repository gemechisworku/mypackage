# Description

This is python package creation example.
Feel free to go over this package and see how it works

# Installation

The installation is pretty straightforward.
Don't hesitate to try it out.
